apt update
apt-get install libcurl3
apt-get install libqrencode3
apt-get install libboost-system1.55.0
apt-get install libboost-filesystem1.55.0
apt-get install libboost-program-options1.55.0
apt-get install libboost-thread1.55.0
apt-get install libssl1.0.0


