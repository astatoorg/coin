apt update
apt install libcurl3
apt install libqrencode3
dpkg -i libboost-system1.55.0_1.55.0+dfsg-3_amd64.deb
dpkg -i libboost-filesystem1.55.0_1.55.0+dfsg-3_amd64.deb
dpkg -i libboost-program-options1.55.0_1.55.0+dfsg-3_amd64.deb
dpkg -i libboost-thread1.55.0_1.55.0+dfsg-3_amd64.deb
dpkg -i libssl1.0.0_1.0.1t-1+deb8u6_amd64.deb

